package com.capg.paymentwallet.exception;

public class CustomerExceptionMessage {

	public static final String ERROR1 = "Name should contain atleast 4 characters";
    public static final String ERROR2 = "Email should contain @ symbol";
	public static final String ERROR3 = "Age should be greater than 18";
	public static final String ERROR4 = "phone number should contain 10 digits";
	public static final String ERROR5 = "balance should not be negative";
	

	

}
