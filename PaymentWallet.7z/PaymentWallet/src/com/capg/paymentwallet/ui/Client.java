package com.capg.paymentwallet.ui;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.WalletTransaction;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;
import com.capg.paymentwallet.util.DataBase;

public class Client {

	static IAccountService service = new AccountServiceImpl();

	DataBase dataBase = new DataBase();

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws Exception {

		while (true) {
			System.out.println("********Payment Wallet**********");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit Amount");
			System.out.println("3.Withdraw Amount");
			System.out.println("4.Show Balance");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			System.out.println("Enter choice:");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				createAccount();

				break;

			case 2:
				deposit();

				break;

			case 3:
				withdraw();

				break;

			case 4:
				showBalance();
				break;

			case 5:
				fundTransfer();
				break;

			case 6:
				printTransactions();
				break;

			case 7:
				System.exit(0);

				break;

			default:
				break;
			}
		}
	}

	private static void createAccount() throws Exception {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name:");
		String name = sc.next();
		System.out.println("Enter emailId:");
		String emailId = sc.next();
		System.out.println("Enter age:");
		int age = sc.nextInt();
		System.out.println("Enter phone Number:");
		BigInteger phNo = sc.nextBigInteger();
		CustomerBean customerBean = new CustomerBean();
		customerBean.setName(name);
		customerBean.setPhNo(phNo);
		customerBean.setEmailId(emailId);
		customerBean.setAge(age);

		//System.out.println("Enter  Account ID");
		//int accountId = scanner.nextInt();

		System.out.println("Enter Date of Opening (DD/MM/YYYY)");
		String accDateInput = scanner.next();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dateOfOpeining = sdf.parse(accDateInput);
		
		

		System.out.println("Enter balance to create account");
		double balance = scanner.nextDouble();

		AccountBean accountBean = new AccountBean();
		//accountBean.setAccountId(accountId);
		accountBean.setBalance(balance);
		accountBean.setInitialDeposit(balance);
		accountBean.setCustomerBean(customerBean);
		;

		try {

			boolean isValid = service.createAccount(accountBean);
			if (isValid) {
				System.out.println("\n\n\t\tcreated successfully\n\n\t\t");
			}

		} catch (CustomerException exception) {

			System.out.println("\n\n\t\tInvalid Data\n\n\t\t" );
		}

	}

	private static void deposit() throws Exception {

		System.out.println("Enter Account Id:");
		int accountId = scanner.nextInt();
		AccountBean accountBean = service.findAccount(accountId);

		System.out.println("Enter amount that you want to deposit: ");
		double depositAmt = scanner.nextDouble();

		WalletTransaction wt=new WalletTransaction();
		wt.setTransactionType(1);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(depositAmt);
		wt.setBeneficiaryAccountBean(null);
		
		accountBean.addTransation(wt);
		
		if (accountBean == null) {
			System.out.println("Account Does not exist");
			return ;
		}
		boolean result = service.deposit(accountBean, depositAmt);

		if (result) {
			System.out.println("\n\tDeposited Money into Account\n\t ");
		} else {
			System.out.println("\n\tNOT Deposited Money into Account\n\t ");
		}

	}

	private static void withdraw() throws Exception {
		System.out.println("Enter Account Id:");
		int accountId = scanner.nextInt();
		AccountBean accountBean = service.findAccount(accountId);

		System.out.println("Enter amount that you want to withdraw: ");
		double withdrawAmt = scanner.nextDouble();
		
		WalletTransaction wt=new WalletTransaction();
		wt.setTransactionType(2);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(withdrawAmt);
		wt.setBeneficiaryAccountBean(null);
		
		accountBean.addTransation(wt);

		if (accountBean == null) {
			System.out.println("\n\tAccount Does not exist\n\t");
			return;
		}
		boolean result = service.withdraw(accountBean, withdrawAmt);

		if (result) {
			System.out.println("\n\twithadrawn Money from Account \n\t");
		} else {
			System.out.println("\n\t NOT withdrawed Money from Account\n\t ");
		}
	}

	private static void showBalance() throws Exception {
		CustomerBean customerBean = new CustomerBean();
		System.out.println("Enter Account Id:");
		int accountId = scanner.nextInt();
		AccountBean accountBean = service.findAccount(accountId);

		if (accountBean == null) {
			System.out.println("Account Does not exist");
			return;
		}

		double balance = accountBean.getBalance();
        System.out.println(customerBean.getName());
		System.out.println("Your balance is: " + balance);

	}

	private static void fundTransfer() throws Exception {
		System.out.println("Enter Account ID to Transfer Money From");
		int srcAccId=scanner.nextInt();
		
		AccountBean accountBean1=service.findAccount(srcAccId);
		
		
		System.out.println("Enter Account ID to Transfer Money to");
		int targetAccId=scanner.nextInt();
		
		AccountBean accountBean2=service.findAccount(targetAccId);
		
		System.out.println("Enter amount that you want to transfer");
		double transferAmt=scanner.nextDouble();
		
		WalletTransaction wt=new WalletTransaction();
		wt.setTransactionType(3);
		wt.setTransactionDate(new Date());
		wt.setTransactionAmt(transferAmt);
		wt.setBeneficiaryAccountBean(accountBean2);
		
		accountBean1.addTransation(wt);

		boolean result=service.fundTransfer(accountBean1, accountBean2, transferAmt);
		
		if(result){
			System.out.println("\n\tTransfering Money from Account done\n\t");
		}else{
			System.out.println("\n\tTransfering Money from Account Failed\n\t ");
		}

	}

	private static void printTransactions() throws Exception {

		System.out.println("Enter Account ID (for printing Transaction Details");
		int accId=scanner.nextInt();
		
		AccountBean accountBean=service.findAccount(accId);
		
		List<WalletTransaction>  transactions=accountBean.getAllTransaction();
		
		System.out.println(accountBean);
		System.out.println(accountBean.getCustomerBean());
		
		System.out.println("------------------------------------------------------------------");
		
		for(WalletTransaction wt:transactions){
			
			String str="";
			if(wt.getTransactionType()==1){
				str=str+"DEPOSIT";
			}
			if(wt.getTransactionType()==2){
				str=str+"WITHDRAW";
			}
			if(wt.getTransactionType()==3){
				str=str+"FUND TRANSFER";
			}
			
			str=str+"\t\t"+wt.getTransactionDate();
			
			str=str+"\t\t"+wt.getTransactionAmt();
			System.out.println(str);
		}
		
		System.out.println("------------------------------------------------------------------");
	
	}

}