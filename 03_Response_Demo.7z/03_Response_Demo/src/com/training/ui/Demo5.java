package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Player;

/**
 * Servlet implementation class Demo5
 */
@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Set<Player> player = new HashSet<>();
		
		Player p1 = new Player(101, "Dhoni", 10, 450, 360, true);
		Player p2 = new Player(102, "Sachin",12, 550, 470, true);
		Player p3 = new Player(103, "shourya", 13,400, 360, false);
		Player p4 = new Player(104, "Virat", 25, 350, 350, true);
		Player p5 = new Player(105, "Ghambir", 16, 250, 350, false);
		Player p6 = new Player(106, "ram", 37, 150, 560, false);
		Player p7 = new Player(107, "tarak", 18, 250, 460, true);
		Player p8 = new Player(108, "charan", 29, 250, 560,false);
		Player p9 = new Player(109, "vijay", 24, 350, 460, false);
		player.add(p1);
		player.add(p2);
		player.add(p3);
		player.add(p4);
		player.add(p5);
		player.add(p6);
		player.add(p7);
		player.add(p8);
		player.add(p9);
		
		response.setContentType("text/html");
		out.println("<link href = 'Style.css' rel='Stylesheet'> ");
		out.println("<table border='4px'>");
		out.println("<tr>");
	    out.println("<th>PlayerID</th>");
	    out.println("<th>playerName</th>");
	    out.println("<th>noOfmatches</th>");
	    out.println("<th>totalRunsScored</th>");
	    out.println("<th>noOfWickets</th>");
	    out.println("<th>captain</th>");
	    out.println("<th>BattingRating</th>");
	    out.println("<th>BowlingRating</th>");
	    out.println("</tr>");
	    
	    for (Player p : player) {
	    	out.println("<tr>");
		    out.println("<td>"+p.getPlayerId()+"</th>");
		    out.println("<td>"+p.getPlayerName()+"</th>");
		    out.println("<td>"+p.getNoOfmatches()+"</th>");
		    out.println("<td>"+p.getTotalRunsScored()+"</th>");
		    out.println("<td>"+p.getNoOfWickets()+"</th>");
		    out.println("<td>"+p.isCaptain()+"</th>");
		    out.println("<td>"+p.getBattingRating()+"</th>");
		    out.println("<td>"+p.getBowlingRating()+"</th>");
		    out.println("</tr>");
		    
	    }
	    out.println("</table>");
		

	}

}
