package com.training.entity;

public class Player {
	
	 int playerId;
	String playerName;
	int noOfmatches;
	int totalRunsScored;
	int noOfWickets;
	boolean captain;
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getNoOfmatches() {
		return noOfmatches;
	}
	public void setNoOfmatches(int noOfmatches) {
		this.noOfmatches = noOfmatches;
	}
	public int getTotalRunsScored() {
		return totalRunsScored;
	}
	public void setTotalRunsScored(int totalRunsScored) {
		this.totalRunsScored = totalRunsScored;
	}
	public int getNoOfWickets() {
		return noOfWickets;
	}
	public void setNoOfWickets(int noOfWickets) {
		this.noOfWickets = noOfWickets;
	}
	public boolean isCaptain() {
		return captain;
	}
	public void setCaptain(boolean captain) {
		this.captain = captain;
	}
	public Player(int playerId, String playerName, int noOfmatches,
			int totalRunsScored, int noOfWickets, boolean captain) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.noOfmatches = noOfmatches;
		this.totalRunsScored = totalRunsScored;
		this.noOfWickets = noOfWickets;
		this.captain = captain;
	}
	public Player() {
		super();
	}
	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", playerName=" + playerName
				+ ", noOfmatches=" + noOfmatches + ", totalRunsScored="
				+ totalRunsScored + ", noOfWickets=" + noOfWickets
				+ ", captain=" + captain + "]";
	}
	
	public String getBattingRating(){
		double avg = this.totalRunsScored/this.noOfmatches;
		if(avg>40){
			return "BEST";
		}else if (avg>=30) {
			return "GOOD";
		}else if (avg>=20) {
			return "AVERAGE";
		}else{
			return "POOR";
		}
		 
	}
	
	public String getBowlingRating(){
		double avg = this.noOfWickets/this.noOfmatches;
		if(avg>40){
			return "BEST";
		}else if (avg>=30) {
			return "GOOD";
		}else if (avg>=15) {
			return "AVERAGE";
		}else{
			return "POOR";
		}
		 
	}

}
